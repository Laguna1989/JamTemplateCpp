var searchData=
[
  ['serializer_863',['serializer',['../classnlohmann_1_1detail_1_1serializer.html',1,'nlohmann::detail']]],
  ['static_5fconst_864',['static_const',['../structnlohmann_1_1detail_1_1static__const.html',1,'nlohmann::detail']]]
];
